---
name: Autonomous Mobility Fintech
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#42474c'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#73787c'
  outline-variant: '#c2c7cc'
  surface-tint: '#486172'
  primary: '#001622'
  on-primary: '#ffffff'
  primary-container: '#102b3a'
  on-primary-container: '#7993a5'
  inverse-primary: '#b0cadd'
  secondary: '#006c52'
  on-secondary: '#ffffff'
  secondary-container: '#84f8cf'
  on-secondary-container: '#007257'
  tertiary: '#04151f'
  on-tertiary: '#ffffff'
  tertiary-container: '#192a34'
  on-tertiary-container: '#80929e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cbe6fa'
  primary-fixed-dim: '#b0cadd'
  on-primary-fixed: '#011e2d'
  on-primary-fixed-variant: '#314a5a'
  secondary-fixed: '#84f8cf'
  secondary-fixed-dim: '#67dbb3'
  on-secondary-fixed: '#002117'
  on-secondary-fixed-variant: '#00513d'
  tertiary-fixed: '#d3e5f3'
  tertiary-fixed-dim: '#b7c9d7'
  on-tertiary-fixed: '#0c1d27'
  on-tertiary-fixed-variant: '#384954'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans, system-ui
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans, system-ui
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans, system-ui
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans, system-ui
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans, system-ui
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans, system-ui
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter, system-ui
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter, system-ui
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter, system-ui
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans, system-ui
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans, system-ui
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  currency-display:
    fontFamily: Plus Jakarta Sans, system-ui
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  plate-display:
    fontFamily: Plus Jakarta Sans, monospace
    fontSize: 22px
    fontWeight: '800'
    lineHeight: 28px
    letterSpacing: 0.15em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.25rem
---

## Brand & Style

This design system drives an automated, ambient vehicle-fintech platform facilitating seamless drive-thru, parking, fueling, and car wash transactions via Automatic License Plate Recognition (ALPR) and geofencing. 

The aesthetic is **Precision Mobility Fintech**: sleek, authoritative, modern, and effortless. The design balances bank-grade institutional trust with the low-latency speed of automated edge computing. High-contrast surfaces, micro-tactile status indications, and ambient elevation build user confidence during high-value, hands-free transactions.

Key tenets:
- **Zero Friction & Visibility:** Interactions must communicate financial security, vehicle recognition, and geofence state in milliseconds.
- **Bilingual & Bi-directional Native:** Parity between English and Arabic layouts, honoring RTL typographic flow, symmetrical padding, and flipped directional cues without visual decay.
- **Physical-Digital Alignment:** Visual motifs mirror physical license plate geometry, optical recognition targeting reticles, and live perimeter monitoring.

## Colors

The palette leverages a deep maritime slate navy anchored by an electric emerald payment green, ensuring maximum legibility, financial confidence, and high-contrast recognition across bright outdoor glare and in-vehicle displays.

### Primary & Dark Accent
- **Primary Navy (`#102B3A`):** Core structural surfaces, header bars, bold typography, and primary interactive containers.
- **Dark Surface (`#0B1D27`):** Elevated dark cards, camera view overlays, ALPR terminal preview modules, and inverted night-mode containers.

### Accent & Feedback
- **Emerald Accent (`#079875`):** Payment confirmations, active vehicle matching states, funded wallets, and primary call-to-action triggers.
- **Amber Attention (`#F59E0B`):** Geofence approach state, approaching toll gates, and low-balance warnings.
- **Crimson Hazard (`#EF4444`):** Plate match failure, transaction decline, blocked vehicle, or unlinked card.
- **Info Blue (`#3B82F6`):** Active telemetry, geofence radius ping, and camera stream diagnostics.

### Neutral & Foundation
- **Base Canvas (`#FFFFFF`):** Primary light mode canvas.
- **Surface Level 1 (`#F8FAFC`):** Main app background, grouped row backgrounds, subtle cards.
- **Surface Level 2 (`#F1F5F9`):** Input fills, segmented controls, badge backdrops.
- **Border Default (`#E2E8F0`):** Hairline structure borders for high daylight legibility.
- **Text Primary (`#0F172A`):** Dominant reading text.
- **Text Muted (`#64748B`):** Metadata, license plate subtitles, and status captions.

## Typography

The type system blends the geometric authority of **Plus Jakarta Sans** for headers, financial metrics, and ALPR badges with the analytical legibility of **Inter** for dense transactional logs.

### Arabic & RTL Support
For Arabic locales, the font stack falls back natively to:
`"IBM Plex Sans Arabic", "Cairo", "Tajawal", -apple-system, BlinkMacSystemFont, sans-serif`.
- Scale optical sizes up by 1px for Arabic text where necessary to maintain visual weight parity with Latin glyphs.
- Avoid all faux italics and letter-spacing expansions on Arabic type.

### Financial & Currency Representation
- Use `currency-display` for KWD balances (e.g., `KD 14.250` or `14.250 د.ك`). Kuwaiti Dinar values require three decimal places; maintain tabular figures (`tnum`) across all pricing and settlement tables to ensure vertical alignment.
- License plate visualizers leverage uppercase wide-tracking (`plate-display`) reminiscent of embossed metallic stamping.

## Layout & Spacing

The layout is built upon an 8-point harmonic grid system designed for touch devices, in-dash web consoles, and operational fleet dashboards.

### Breakpoints & Grid Containers
- **Mobile (0 – 639px):** 4 columns, `margin: 1rem (16px)`, `gutter: 1rem (16px)`. Focus is on instant single-thumb authorization and transaction progress.
- **Tablet (640 – 1023px):** 8 columns, `margin-tablet: 1.5rem (24px)`, `gutter: 1rem (16px)`. Split master-detail view for vehicles and active live feeds.
- **Desktop / Terminal (1024px+):** 12 columns, `margin-desktop: 2.5rem (40px)`, `gutter-desktop: 1.5rem (24px)`. Max content width pinned at `1280px` for optimal scanning.

### RTL Grid Flow
All structural margins and gutters must be mathematically symmetric to prevent container shifting during LTR/RTL toggles. Inline margins must use logical directional properties (`margin-inline-start`, `margin-inline-end`, `padding-inline-start`, `padding-inline-end`).

## Elevation & Depth

Visual hierarchy pairs clean surface outlines with low-opacity, blue-navy tinted ambient shadows to emulate premium physical cards and clean dashboard glass.

### Surface Tiers
- **Base Canvas:** Flat `#FFFFFF` or `#F8FAFC`. No shadow.
- **Elevated Card (Level 1):** Background `#FFFFFF`, 1px solid `#E2E8F0`, shadow `0 1px 3px rgba(16, 43, 58, 0.04), 0 4px 12px rgba(16, 43, 58, 0.03)`.
- **Floating Active Panel (Level 2):** Background `#FFFFFF`, 1px solid `#CBD5E1`, shadow `0 8px 24px rgba(16, 43, 58, 0.08)`. Used for authorization dialogs, slide-over receipts, and vehicle switchers.
- **Overlaid Geofence Target / HUD (Dark Level):** Background `#0B1D27` with 95% opacity, backdrop-filter blur `12px`, border `1px solid rgba(255, 255, 255, 0.1)`. Used for camera scans, real-time ALPR captures, and live drive-thru drive-up alerts.
- **Active State Glow:** Focused vehicle cards or approved payment pulses use an accent glow: `0 0 0 3px rgba(7, 152, 117, 0.25)`.

## Shapes

The interface embraces a unified soft geometry that balances industrial precision with consumer-friendly accessibility.

- **Standard Elements (0.5rem / 8px):** Input boxes, form controls, secondary actions, and micro badges.
- **Large Cards & Modules (1rem / 16px):** Primary transactional blocks, vehicle list cards, and summary sheets.
- **Specialized Surfaces (1.5rem / 24px):** Bottom sheets, modal dialogues, and live camera feed viewports.
- **License Plate Frames:** Fixed standard 0.375rem (6px) radius, bound by a crisp 2px border mimicking physical license plates.
- **Pills (Full Radius / 9999px):** Status chips, currency pill counters, payment method badges, and bilingual switch toggles.

## Components

### 1. Buttons
- **Primary Action (Payment/Authorize):** Filled with Emerald `#079875` (hover `#067D61`), text `#FFFFFF`, rounded 8px (`rounded-md`), min-height 48px for instant tap targets.
- **Brand Action:** Navy `#102B3A` (hover `#0B1D27`), text `#FFFFFF`.
- **Secondary / Outline:** Background transparent, border 1.5px solid `#E2E8F0`, text `#102B3A`, hover background `#F8FAFC`.
- **Destructive:** Background `#FEE2E2`, text `#EF4444`, hover background `#FECACA`.

### 2. Vehicle License Plate Badges
- **Physical Plate Replica:** White or subtle metallic background (`#F8FAFC`), bordered with `#334155` (1.5px), internal vertical divider separating region/country code (e.g., `KUWAIT / الكويت`) from digits. 
- **Typography:** `plate-display` font token, uppercase, centered, tabular digits.

### 3. Cards & Transaction Tiles
- **Vehicle Asset Card:** Card structure (16px padding, 16px roundedness), displaying brand logo, vehicle nickname, license plate token, and default payment card chip.
- **Live Event / ALPR Recognition Card:** Dark card `#0B1D27` with live pulse dot (emerald `#079875`), vehicle thumbnail overlay, optical scan brackets at corners, and instant pre-auth amount in KWD.

### 4. Status Badges & Chips
- **Authorized / Success:** Background `#ECFDF5`, text `#065F46`, border 1px solid `#A7F3D0`.
- **Pending / In Geofence:** Background `#FEF3C7`, text `#92400E`, border 1px solid `#FDE68A`.
- **Declined / Unrecognized:** Background `#FEF2F2`, text `#991B1B`, border 1px solid `#FECACA`.
- **All Badges:** Height 24px, padding 0 8px, text `label-md`, full-pill border radius.

### 5. Input Fields
- **Container:** Height 48px, background `#FFFFFF`, border 1px solid `#CBD5E1`, rounded 8px.
- **Focus:** Border color `#079875` with 3px halo `rgba(7, 152, 117, 0.15)`.
- **Bilingual & RTL Logic:** Icons (magnifier, calendar, cards) float to `inline-start`. Currency suffix (`KWD` or `د.ك`) locks to `inline-end`.

### 6. Checkboxes, Radios, & Toggles
- **Toggles:** 48x28px track. Inactive track `#E2E8F0`, active track `#079875`. Knob `#FFFFFF` with 2px shadow. Smooth transition (150ms cubic-bezier).
- **Radio / Checkbox:** Checked color `#079875`, border `#94A3B8`, rounded-sm (4px) for checkboxes, rounded-full for radios.

### 7. Language Switcher (EN / AR)
- Segmented pill track with background `#F1F5F9`, active indicator `#FFFFFF` with elevation level 1, typography `label-md`, guaranteeing smooth transition without horizontal layout jump.